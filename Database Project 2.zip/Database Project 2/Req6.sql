ALTER TABLE tRentalLine
ADD COLUMN conditionCheckDate DATE,
ADD COLUMN volunteerName VARCHAR(50);

UPDATE tRentalLine
SET conditionCheckDate = '2024-08-25', volunteerName = 'F Fixer'
WHERE rentalNo = 10;

-- View all data in tRentalLine
SELECT * FROM tRentalLine;