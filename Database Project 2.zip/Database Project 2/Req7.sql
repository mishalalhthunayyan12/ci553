ALTER TABLE tEquipment
ADD COLUMN consumables VARCHAR(255);
UPDATE tEquipment
SET consumables = 'sandpaper, glue'
WHERE equipmentID = 'EQ01'; -- Example for wallpaper stripper

UPDATE tEquipment
SET consumables = 'sugar, flavoring'
WHERE equipmentID = 'EQ02'; -- Example for popcorn machine
SELECT 
    e.equipmentName,
    e.consumables
FROM tEquipment e
WHERE e.equipmentID = 'EQ02';  -- Example for popcorn machine
SELECT 
    e.equipmentID,
    e.equipmentName,
    e.consumables
FROM tEquipment e
WHERE NOT EXISTS (
    SELECT 1 
    FROM tRentalLine rl
    JOIN tRental r ON rl.rentalNo = r.rentalNo
    WHERE rl.equipmentID = e.equipmentID
    AND r.collectionDate <= '2025-01-14'  -- Check until January 14, 2025
    AND (r.dateReturned IS NULL OR r.dateReturned >= '2025-01-01')  -- Ensure return after January 1, 2025
);
