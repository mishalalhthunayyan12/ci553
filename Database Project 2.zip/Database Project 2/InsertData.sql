-- Insert data into tUser
INSERT INTO tUser (userID, uFName, uLName, uAddress)
VALUES 
('CC01', 'Cassie', 'Carter', '123 Main St'),
('JB02', 'John', 'Brown', '45 High St'),
('LS03', 'Lily', 'Smith', '78 Park Ave');

-- Insert data into tEquipment
INSERT INTO tEquipment (equipmentID, equipmentName, patTestDate, weeklyCost)
VALUES 
('EQ01', 'Folding Trolley', '2024-04-04', 7.00),
('EQ02', 'Ladder', '2024-05-15', 5.50),
('EQ03', 'Hammer Drill', '2024-06-20', 10.00);

-- Insert data into tRental
INSERT INTO tRental (userID, collectionDate, duration, totalPaid, dateReturned, checkedBy, overduePayment)
VALUES 
('CC01', '2024-08-01', 2, 14.00, '2024-08-15', 'F Fixer', 0.00),
('JB02', '2024-08-05', 1, 10.00, '2024-08-12', 'A Inspector', 2.00);

-- Insert data into tRentalLine
INSERT INTO tRentalLine (rentalNo, equipmentID, subtotal)
VALUES 
(1, 'EQ01', 14.00),
(2, 'EQ03', 10.00);