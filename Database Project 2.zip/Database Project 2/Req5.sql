SELECT 
    e.equipmentID,
    e.equipmentName,
    e.patTestDate,
    DATE_ADD(e.patTestDate, INTERVAL 1 YEAR) AS nextPatTestDate
FROM tEquipment e
WHERE e.equipmentName LIKE 'Electric%'  -- Match electrical equipment that starts with "Electric"
AND DATE_ADD(e.patTestDate, INTERVAL 1 YEAR) <= CURDATE() + INTERVAL 1 MONTH
AND DATE_ADD(e.patTestDate, INTERVAL 1 YEAR) > CURDATE(); -- PAT test due within the next month
