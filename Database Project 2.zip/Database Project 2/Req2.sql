INSERT INTO tUser (userID, uFName, uLName, uAddress)
VALUES ('MW11', 'Mia', 'Williams', '12 Elm Street');
INSERT INTO tEquipment (equipmentID, equipmentName, patTestDate, weeklyCost)
VALUES ('EQ14', 'Wallpaper Stripper', '2024-10-01', 15.00);
INSERT INTO tRental (userID, collectionDate, duration, totalPaid)
VALUES ('MW11', '2024-10-05', 2, 30.00);
INSERT INTO tRentalLine (rentalNo, equipmentID, subtotal)
VALUES (LAST_INSERT_ID(), 'EQ14', 30.00);
