CREATE VIEW vRentalSummary AS
SELECT 
    r.rentalNo,
    r.userID,
    u.uFName,
    u.uLName,
    r.collectionDate,
    r.dateReturned,
    e.equipmentName,
    rl.subtotal
FROM tRental r
JOIN tRentalLine rl ON r.rentalNo = rl.rentalNo
JOIN tEquipment e ON rl.equipmentID = e.equipmentID
JOIN tUser u ON r.userID = u.userID
WHERE r.dateReturned IS NOT NULL;

SELECT * FROM vRentalSummary;
