DELIMITER $$

CREATE PROCEDURE CalculateSubtotal(IN rentalNo INT)
BEGIN
    DECLARE total DECIMAL(10,2);
    
    SELECT SUM(subtotal) INTO total
    FROM tRentalLine
    WHERE rentalNo = rentalNo;
    
    UPDATE tRental
    SET totalPaid = total
    WHERE rentalNo = rentalNo;
END $$

DELIMITER ;
