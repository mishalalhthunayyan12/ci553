-- Use the existing RentalDB database
USE RentalDB;

-- Insert additional data into tUser
INSERT INTO tUser (userID, uFName, uLName, uAddress)
VALUES 
('CC02', 'Charles', 'Carter', '34 Green St'),
('CC03', 'Clara', 'Carter', '56 Maple St'),
('JB03', 'Jake', 'Brown', '12 Oak St'),
('LS04', 'Liam', 'Smith', '99 Pine St'),
('RM05', 'Rachel', 'Martin', '101 Cedar St'),
('EG06', 'Eva', 'Green', '22 Elm St'),
('MH07', 'Michael', 'Hunt', '65 Birch St'),
('JS08', 'Jason', 'Stone', '88 Willow St'),
('AL09', 'Alex', 'Lee', '45 Cherry St'),
('TN10', 'Tina', 'Nguyen', '72 Ash St');

-- Insert additional data into tEquipment
INSERT INTO tEquipment (equipmentID, equipmentName, patTestDate, weeklyCost)
VALUES 
('EQ04', 'Electric Drill', '2024-07-10', 15.00),
('EQ05', 'Circular Saw', '2024-08-10', 20.00),
('EQ06', 'Pressure Washer', '2024-05-20', 25.00),
('EQ07', 'Wood Cutter', '2024-06-15', 18.00),
('EQ08', 'Sander', '2024-04-12', 8.00),
('EQ09', 'Welder', '2024-08-01', 30.00),
('EQ10', 'Compressor', '2024-06-25', 35.00),
('EQ11', 'Chainsaw', '2024-07-18', 22.00),
('EQ12', 'Lawn Mower', '2024-06-30', 14.00),
('EQ13', 'Generator', '2024-05-10', 40.00);

-- Insert additional data into tRental
INSERT INTO tRental (userID, collectionDate, duration, totalPaid, dateReturned, checkedBy, overduePayment)
VALUES 
('CC02', '2024-08-15', 3, 21.00, '2024-08-20', 'F Fixer', 0.00),
('CC03', '2024-08-17', 1, 18.00, '2024-08-24', 'A Inspector', 5.00),
('JB03', '2024-08-19', 2, 30.00, '2024-08-25', 'F Fixer', 0.00),
('LS04', '2024-08-22', 4, 40.00, '2024-08-30', 'A Inspector', 10.00),
('RM05', '2024-08-23', 1, 12.00, '2024-08-30', 'F Fixer', 0.00),
('EG06', '2024-08-25', 3, 45.00, '2024-09-05', 'A Inspector', 15.00),
('MH07', '2024-08-28', 5, 55.00, '2024-09-10', 'F Fixer', 0.00),
('JS08', '2024-09-01', 1, 20.00, '2024-09-08', 'A Inspector', 3.00),
('AL09', '2024-09-03', 2, 30.00, '2024-09-09', 'F Fixer', 2.00),
('TN10', '2024-09-05', 1, 14.00, '2024-09-12', 'A Inspector', 0.00);

-- Insert additional data into tRentalLine
INSERT INTO tRentalLine (rentalNo, equipmentID, subtotal)
VALUES 
(3, 'EQ05', 21.00),
(4, 'EQ06', 40.00),
(5, 'EQ07', 36.00),
(6, 'EQ08', 24.00),
(7, 'EQ09', 45.00),
(8, 'EQ10', 70.00),
(9, 'EQ11', 44.00),
(10, 'EQ12', 28.00),
(11, 'EQ13', 40.00),
(12, 'EQ04', 15.00);
