INSERT INTO tUser (userID, uFName, uLName, uAddress)
VALUES ('INVALIDID', 'Invalid', 'User', 'Invalid Address');

DELETE FROM tUser WHERE userID = 'CC01';
