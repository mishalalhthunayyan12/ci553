-- View all data in tUser
SELECT * FROM tUser;

-- View all data in tEquipment
SELECT * FROM tEquipment;


-- View all data in tRental
SELECT * FROM tRental;

-- View all data in tRentalLine
SELECT * FROM tRentalLine;