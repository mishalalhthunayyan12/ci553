-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: rentaldb
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trental`
--

DROP TABLE IF EXISTS `trental`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trental` (
  `rentalNo` int NOT NULL AUTO_INCREMENT,
  `userID` char(4) NOT NULL,
  `collectionDate` date NOT NULL,
  `duration` int NOT NULL DEFAULT '1',
  `totalPaid` decimal(6,2) DEFAULT NULL,
  `dateReturned` date DEFAULT NULL,
  `checkedBy` varchar(50) DEFAULT NULL,
  `overduePayment` decimal(6,2) DEFAULT NULL,
  PRIMARY KEY (`rentalNo`),
  KEY `userID` (`userID`),
  CONSTRAINT `trental_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `tuser` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trental`
--

LOCK TABLES `trental` WRITE;
/*!40000 ALTER TABLE `trental` DISABLE KEYS */;
INSERT INTO `trental` VALUES (2,'JB02','2024-08-05',1,10.00,'2024-08-12','A Inspector',2.00),(3,'CC02','2024-08-15',3,21.00,'2024-08-20','F Fixer',0.00),(4,'CC03','2024-08-17',1,18.00,'2024-08-24','A Inspector',5.00),(5,'JB03','2024-08-19',2,30.00,'2024-08-25','F Fixer',0.00),(6,'LS04','2024-08-22',4,40.00,'2024-08-30','A Inspector',10.00),(7,'RM05','2024-08-23',1,12.00,'2024-08-30','F Fixer',0.00),(8,'EG06','2024-08-25',3,45.00,'2024-09-05','A Inspector',15.00),(9,'MH07','2024-08-28',5,55.00,'2024-09-10','F Fixer',0.00),(10,'JS08','2024-09-01',1,20.00,'2024-09-08','A Inspector',3.00),(11,'AL09','2024-09-03',2,30.00,'2024-09-09','F Fixer',2.00),(12,'TN10','2024-09-05',1,14.00,'2024-09-12','A Inspector',0.00),(13,'MW11','2024-10-05',2,30.00,NULL,NULL,NULL);
/*!40000 ALTER TABLE `trental` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-07 23:59:18
