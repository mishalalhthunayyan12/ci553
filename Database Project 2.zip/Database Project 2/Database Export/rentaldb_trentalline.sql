-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: rentaldb
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trentalline`
--

DROP TABLE IF EXISTS `trentalline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trentalline` (
  `rentalLineID` int NOT NULL AUTO_INCREMENT,
  `rentalNo` int NOT NULL,
  `equipmentID` char(4) NOT NULL,
  `subtotal` decimal(6,2) NOT NULL,
  `conditionCheckDate` date DEFAULT NULL,
  `volunteerName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`rentalLineID`),
  KEY `rentalNo` (`rentalNo`),
  KEY `equipmentID` (`equipmentID`),
  CONSTRAINT `trentalline_ibfk_1` FOREIGN KEY (`rentalNo`) REFERENCES `trental` (`rentalNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `trentalline_ibfk_2` FOREIGN KEY (`equipmentID`) REFERENCES `tequipment` (`equipmentID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trentalline`
--

LOCK TABLES `trentalline` WRITE;
/*!40000 ALTER TABLE `trentalline` DISABLE KEYS */;
INSERT INTO `trentalline` VALUES (2,2,'EQ03',10.00,NULL,NULL),(3,3,'EQ05',21.00,NULL,NULL),(4,4,'EQ06',40.00,NULL,NULL),(5,5,'EQ07',36.00,NULL,NULL),(6,6,'EQ08',24.00,NULL,NULL),(7,7,'EQ09',45.00,NULL,NULL),(8,8,'EQ10',70.00,NULL,NULL),(9,9,'EQ11',44.00,NULL,NULL),(10,10,'EQ12',28.00,'2024-08-25','F Fixer'),(11,11,'EQ13',40.00,NULL,NULL),(12,12,'EQ04',15.00,NULL,NULL),(13,13,'EQ14',30.00,NULL,NULL);
/*!40000 ALTER TABLE `trentalline` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-07 23:59:18
