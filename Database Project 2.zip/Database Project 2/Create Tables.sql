
-- Create tUser Table
CREATE TABLE tUser (
    userID CHAR(4) PRIMARY KEY,
    uFName VARCHAR(50) NOT NULL,
    uLName VARCHAR(50) NOT NULL,
    uAddress VARCHAR(100) NOT NULL
);

-- Create tEquipment Table
CREATE TABLE tEquipment (
    equipmentID CHAR(4) PRIMARY KEY,
    equipmentName VARCHAR(100) NOT NULL,
    patTestDate DATE,
    weeklyCost DECIMAL(6,2) NOT NULL
);

-- Create tRental Table
CREATE TABLE tRental (
    rentalNo INT AUTO_INCREMENT PRIMARY KEY,
    userID CHAR(4) NOT NULL,
    collectionDate DATE NOT NULL,
    duration INT NOT NULL DEFAULT 1,
    totalPaid DECIMAL(6,2),
    dateReturned DATE,
    checkedBy VARCHAR(50),
    overduePayment DECIMAL(6,2),
    FOREIGN KEY (userID) REFERENCES tUser(userID) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create tRentalLine Table
CREATE TABLE tRentalLine (
    rentalLineID INT AUTO_INCREMENT PRIMARY KEY,
    rentalNo INT NOT NULL,
    equipmentID CHAR(4) NOT NULL,
    subtotal DECIMAL(6,2) NOT NULL,
    FOREIGN KEY (rentalNo) REFERENCES tRental(rentalNo) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (equipmentID) REFERENCES tEquipment(equipmentID) ON DELETE CASCADE ON UPDATE CASCADE
);
