SELECT 
    r.rentalNo,
    r.userID,
    r.collectionDate,
    r.duration,
    r.totalPaid,
    r.dateReturned,
    e.equipmentID,
    e.equipmentName,
    rl.subtotal
FROM tRental r
JOIN tRentalLine rl ON r.rentalNo = rl.rentalNo
JOIN tEquipment e ON rl.equipmentID = e.equipmentID
WHERE r.userID = 'CC02'
ORDER BY r.collectionDate;
