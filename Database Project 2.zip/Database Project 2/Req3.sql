SELECT 
    e.equipmentName,
    COUNT(rl.rentalNo) AS rentalCount
FROM tRentalLine rl
JOIN tEquipment e ON rl.equipmentID = e.equipmentID
GROUP BY e.equipmentName
ORDER BY rentalCount DESC;

SELECT 
    e.equipmentName
FROM tEquipment e
LEFT JOIN tRentalLine rl ON e.equipmentID = rl.equipmentID
WHERE rl.rentalNo IS NULL;

