SELECT 
    r.rentalNo,
    r.userID,
    r.collectionDate,
    r.duration,
    e.equipmentName,
    rl.subtotal
FROM tRental r
JOIN tRentalLine rl ON r.rentalNo = rl.rentalNo
JOIN tEquipment e ON rl.equipmentID = e.equipmentID
WHERE r.dateReturned IS NULL
ORDER BY r.collectionDate;
