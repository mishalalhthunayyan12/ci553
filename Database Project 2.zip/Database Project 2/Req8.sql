-- Create tCategory Table with VARCHAR for categoryID
CREATE TABLE tCategory (
    categoryID VARCHAR(10) PRIMARY KEY,
    categoryName VARCHAR(50) NOT NULL
);

-- Create tEquipmentCategory Table (Junction Table)
CREATE TABLE tEquipmentCategory (
    equipmentID CHAR(4) NOT NULL,
    categoryID VARCHAR(10) NOT NULL,  -- Adjusted to match VARCHAR(10) in tCategory
    PRIMARY KEY (equipmentID, categoryID),
    FOREIGN KEY (equipmentID) REFERENCES tEquipment(equipmentID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (categoryID) REFERENCES tCategory(categoryID) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO tCategory (categoryID, categoryName)
VALUES 
    ('CAT01', 'Camping'),
    ('CAT02', 'DIY'),
    ('CAT03', 'Party'),
    ('CAT04', 'Events');
INSERT INTO tEquipmentCategory (equipmentID, categoryID)
VALUES
    ('EQ01', 'CAT01'),  -- Trolley in Camping
    ('EQ01', 'CAT04'),  -- Trolley in Events
    ('EQ02', 'CAT01');  -- Tent in Camping

SELECT 
    e.equipmentID,
    e.equipmentName,
    c.categoryName
FROM tEquipment e
JOIN tEquipmentCategory ec ON e.equipmentID = ec.equipmentID
JOIN tCategory c ON ec.categoryID = c.categoryID
WHERE c.categoryName IN ('Camping', 'DIY')
ORDER BY e.equipmentName;
